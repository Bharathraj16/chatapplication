package com.example.zegocloud;

public class KeyConstant {
    public static Long appId=569084855L;
    public static String appSign="682896faae7e80cc3b547288e41009617b132b97a02e78950562998ae3e355dc";

}
